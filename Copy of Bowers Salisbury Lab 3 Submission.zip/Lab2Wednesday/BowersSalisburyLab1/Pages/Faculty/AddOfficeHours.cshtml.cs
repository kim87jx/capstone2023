using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.NewFolder4
{
    public class AddOfficeHoursModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
