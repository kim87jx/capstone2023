using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.Faculty
{
    public class ManageHoursModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
