using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.Faculty
{
    public class FacultyFirstPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
