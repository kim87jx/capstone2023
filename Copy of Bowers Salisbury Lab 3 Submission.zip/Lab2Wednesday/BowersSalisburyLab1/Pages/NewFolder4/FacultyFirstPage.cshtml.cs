using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.NewFolder4
{
    public class FacultyFirstPageModel : PageModel
    {
        [BindProperty]
        public Faculty fac { get; set; }

        public String LoginMessage { get; set; }

        //Logout message
        public void OnGet(String logout)
        {
            if (logout != null)
            {
                HttpContext.Session.Clear();
                LoginMessage = "Logged out Successfully!";
            }
        }

        //Query confirms that users inputted credentials are correct and exist
        public IActionResult OnPost()
        {
            String loginQuery = "SELECT COUNT(*) FROM Faculty where FacultyEmail = '";
            loginQuery += fac.FacultyEmail + "' and FacultyPW='" + fac.FacultyPW + "'";


            if (DBClass.LoginQuery(loginQuery) > 0)
            {
                HttpContext.Session.SetString("fac.FacultyEmail", fac.FacultyEmail);
                return RedirectToPage("FacultyLandingPage");
            } else
            {
                LoginMessage = "Email or Password Incorrect";
            }
            DBClass.DBConnection.Close();
            return Page();
        }
    }
}
