using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.NewFolder4
{
    public class NotifyStudentModel : PageModel
    {
        [BindProperty]
        public string Messsage { get; set; }
        public void OnGet()
        {
        }
    }
}
