using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.NewFolder4
{
    public class ConfirmationSentModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
