using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System;

namespace BowersSalisburyLab1.Pages.NewFolder4
{
    public class FacultyMeetingsModel : PageModel
    {
        public String facID { get; set; }

        public void OnGet()
        {
            SqlDataReader cmdsreader = DBClass.FacFinder(HttpContext.Session.GetString("username"));
            while (cmdsreader.Read())
            {
                facID = cmdsreader["FacultyID"].ToString();
            }
            DBClass.DBConnection.Close();

            HttpContext.Session.SetString("FacultyID", facID);

        }
    }
}
