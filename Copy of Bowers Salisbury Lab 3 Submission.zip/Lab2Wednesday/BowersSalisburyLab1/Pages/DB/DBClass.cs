﻿using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB.GroceryInventory.Pages.DB;
using BowersSalisburyLab1.Pages.StudentFolder;
using Microsoft.AspNetCore.Identity;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.DB
{
    public class DBClass
    {
        //Connection string to connect to database "Lab1".
        public static SqlConnection DBConnection = new SqlConnection();
        private static readonly String? DBConnectionString = "Server=Localhost;Database=Lab3;Trusted_Connection=true";

        public static SqlConnection DBAUTHConnection = new SqlConnection();
        private static readonly String? DBAUTHConnectionString = "Server=Localhost;Database=AUTH;Trusted_Connection=true";

        //Reads OfficeHours table.
        public static SqlDataReader OfficeHoursReader()
        {
            SqlCommand cmdOHReader = new SqlCommand();
            cmdOHReader.Connection = DBConnection;
            cmdOHReader.Connection.ConnectionString = DBConnectionString;

            cmdOHReader.Connection.Open();
            SqlDataReader tempReader = cmdOHReader.ExecuteReader();
            return tempReader;
        }

        //Reads Faculty table.
        public static SqlDataReader FacultyReader()
        {
            SqlCommand cmdOHReader = new SqlCommand();
            cmdOHReader.Connection = DBConnection;
            
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdOHReader.Connection.ConnectionString = DBConnectionString;
            }

            cmdOHReader.CommandText = "SELECT * FROM Faculty";

            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdOHReader.Connection.Open();
            }
            
            SqlDataReader tempReader = cmdOHReader.ExecuteReader();
            return tempReader;
        }

        //Inserts new student into Student table.
        public static void InsertStudent(Student s)
        {
            String sqlQuery = "INSERT INTO Student (StudentID, StudentName, StudentPW, StudentUsername) VALUES (";
            sqlQuery += s.StudentID + ", '";
            sqlQuery += s.StudentName + "', '";
            sqlQuery += s.StudentPW + "', '";
            sqlQuery += s.StudentUsername + "')";

            SqlCommand cmdStudentReader = new SqlCommand();
            cmdStudentReader.Connection = DBConnection;
            cmdStudentReader.Connection.ConnectionString = DBConnectionString;
            cmdStudentReader.CommandText = sqlQuery;
            cmdStudentReader.Connection.Open();

            cmdStudentReader.ExecuteNonQuery();
        }

        //Searches OfficeHoursTable for specific office hours.
        public static SqlDataReader SearchForOH(Student s)
        {


            SqlCommand cmdOfficeHourRead = new SqlCommand();
            cmdOfficeHourRead.Connection = DBConnection;
            cmdOfficeHourRead.Connection.ConnectionString = DBConnectionString;
            cmdOfficeHourRead.CommandText = "SELECT * FROM Meeting WHERE StudentID = " + s.StudentID;
            cmdOfficeHourRead.Connection.Open();

            SqlDataReader tempReader = cmdOfficeHourRead.ExecuteReader();
            return tempReader;

        }

        //Reads OfficeHours table.
        public static SqlDataReader OHReader()
        {

            SqlCommand cmdProductRead = new SqlCommand();
            cmdProductRead.Connection = DBConnection;
            cmdProductRead.Connection.ConnectionString = DBConnectionString;
            cmdProductRead.CommandText = "SELECT * FROM OfficeHours";
            cmdProductRead.Connection.Open();

            SqlDataReader tempReader = cmdProductRead.ExecuteReader();

            return tempReader;
        }

        //Searches Faculty table for specific faculty member.
        public static SqlDataReader SearchFaculty(string FacultyName)
        {
            String sqlQuery = "select  OH.OHDateTime, OH.OfficeID " +
                "from Faculty F, OfficeHours OH where F.FacultyID = OH.FacultyID AND F.FacultyName = '";
            sqlQuery += FacultyName + "';";

            SqlCommand cmdFacRead = new SqlCommand();
            cmdFacRead.Connection = DBConnection;
            cmdFacRead.Connection.ConnectionString = DBConnectionString;
            cmdFacRead.CommandText = sqlQuery;
            cmdFacRead.Connection.Open();

            SqlDataReader tempReader = cmdFacRead.ExecuteReader();

            return tempReader;

        }

        //Reads Meeting table.
        public static SqlDataReader MeetingReader()
        {
            SqlCommand cmdMeetingReader = new SqlCommand();
            cmdMeetingReader.Connection = DBConnection;
            cmdMeetingReader.Connection.ConnectionString = DBConnectionString;
            cmdMeetingReader.CommandText = "SELECT * FROM Meeting";

            cmdMeetingReader.Connection.Open();
            SqlDataReader tempReader = cmdMeetingReader.ExecuteReader();
            return tempReader;
        }

        //Searches Student table for a specific student.
        public static SqlDataReader SearchStudent(String  StudentID)
        {
            String sqlQuery = "select  M.MeetingName, M.MeetingPurpose, M.MeetingDateTime " +
                "from Meeting M, Student S where S.StudentID = M.StudentID AND S.StudentID = '";
            sqlQuery += StudentID + "'";

            SqlCommand cmdmeetRead = new SqlCommand();
            cmdmeetRead.Connection = DBConnection;
            cmdmeetRead.Connection.ConnectionString = DBConnectionString;
            cmdmeetRead.CommandText = sqlQuery;
            cmdmeetRead.Connection.Open();

            SqlDataReader tempReader = cmdmeetRead.ExecuteReader();

            return tempReader;

        }

        //Reads Student table.
        public static SqlDataReader StudentReader()
        {
            SqlCommand cmdStudentReader = new SqlCommand();
            cmdStudentReader.Connection = DBConnection;
           
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdStudentReader.Connection.ConnectionString = DBConnectionString;
            }
            cmdStudentReader.CommandText = "SELECT * FROM Student";
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdStudentReader.Connection.Open();
            }
            
            SqlDataReader tempReader = cmdStudentReader.ExecuteReader();
            return tempReader;
        }

        public static void UpdateMeeting(Meeting m)
        {
            string sqlQuery = "UPDATE Meeting SET";
            sqlQuery += "MeetingName='" + m.MeetingName + "',";
            sqlQuery += "MeetingPurpose='" + m.MeetingPurpose + "',";
            sqlQuery += "MeetingDateTime='" + m.MeetingDateTime + "',";
        }

        public static void InsertMeeting(Meeting m)
        {
            String sqlQuery = "INSERT INTO Meeting (MeetingName, MeetingPurpose, MeetingDateTime, NumOfStudents, OfficeID, StudentID) VALUES ('";
            sqlQuery += m.MeetingName + "', '";
            sqlQuery += m.MeetingPurpose + "', '";
            sqlQuery += m.MeetingDateTime + "', ";
            sqlQuery += m.NumOfStudents + ", ";
            sqlQuery += m.OfficeID + ", ";
            sqlQuery += m.StudentID + ")";

            SqlCommand cmdStudentReader = new SqlCommand();
            cmdStudentReader.Connection = DBConnection;
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdStudentReader.Connection.ConnectionString = DBConnectionString;
            }
           
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdStudentReader.Connection.Open();
            }


            cmdStudentReader.CommandText = sqlQuery;
            

            cmdStudentReader.ExecuteNonQuery();
        }

        public static int LoginQuery(string loginQuery)
        {
            // This method expects to receive an SQL SELECT
            // query that uses the COUNT command.
            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBConnection;
            cmdLogin.Connection.ConnectionString = DBConnectionString;
            cmdLogin.CommandText = loginQuery;
            cmdLogin.Connection.Open();
            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();
            return rowCount;
        }


        public static int SecureLogin(string Username, string Password)
        {
            string loginQuery =
                "SELECT COUNT(*) FROM Credentials where Username = @Username and Password = @Password";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBConnection;
            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
               cmdLogin.Connection.ConnectionString = DBConnectionString;
            }

            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.Open();
            }

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", Password);

            cmdLogin.Connection.Open();

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            int rowCount = (int)cmdLogin.ExecuteScalar();

            return rowCount;
        }

        public static bool StudentHashedParameterLogin(string Username, string Password)
        {
            //string loginQuery =
            //    "Sp_";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBAUTHConnection;
            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.ConnectionString = DBAUTHConnectionString;
            }

            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.Open();
            }
            cmdLogin.CommandType = System.Data.CommandType.StoredProcedure;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", Password);
            cmdLogin.CommandText = "sp_Lab3Login";
            

            

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }

        public static bool FacultyHashedParameterLogin(string Username, string Password)
        {
            //string loginQuery =
            //    "SELECT Password FROM HashedCredentials WHERE Username = @Username";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBAUTHConnection;
            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.ConnectionString = DBAUTHConnectionString;
            }

            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.Open();
            }

            cmdLogin.CommandType = System.Data.CommandType.StoredProcedure;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", Password);
            cmdLogin.CommandText = "sp_Lab3LoginFaculty";





            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            SqlDataReader hashReader = cmdLogin.ExecuteReader();
            if (hashReader.Read())
            {
                string correctHash = hashReader["Password"].ToString();

                if (PasswordHash.ValidatePassword(Password, correctHash))
                {
                    return true;
                }
            }

            return false;
        }




        public static void CreateHashedStudent(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO StudentHashedCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBAUTHConnection;
            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.ConnectionString = DBAUTHConnectionString;
            }

            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.Open();
            }

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));

            

            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static void CreateHashedFaculty(string Username, string Password)
        {
            string loginQuery =
                "INSERT INTO FacultyHashedCredentials (Username,Password) values (@Username, @Password)";

            SqlCommand cmdLogin = new SqlCommand();
            cmdLogin.Connection = DBAUTHConnection;
            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.ConnectionString = DBAUTHConnectionString;
            }

            if (DBAUTHConnection.State == System.Data.ConnectionState.Closed)
            {
                cmdLogin.Connection.Open();
            }

            cmdLogin.CommandText = loginQuery;
            cmdLogin.Parameters.AddWithValue("@Username", Username);
            cmdLogin.Parameters.AddWithValue("@Password", PasswordHash.HashPassword(Password));



            // ExecuteScalar() returns back data type Object
            // Use a typecast to convert this to an int.
            // Method returns first column of first row.
            cmdLogin.ExecuteNonQuery();

        }

        public static SqlDataReader GeneralReaderQuery (string sqlQuery)
        {
            SqlCommand generalRead = new SqlCommand();
            generalRead.Connection = DBConnection;

            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                generalRead.Connection.ConnectionString = DBConnectionString;
            }

            if (DBConnection.State == System.Data.ConnectionState.Closed)
            {
                generalRead.Connection.Open();
            }
            generalRead.CommandText = sqlQuery;
         
            SqlDataReader tempReader = generalRead.ExecuteReader();

            return tempReader;
        }

        public static SqlDataReader StudentFinder(String HttpContext)
        {
            String sqlQuery = "SELECT StudentID FROM Student WHERE StudentUsername = '" + HttpContext + "';";

            SqlCommand cmdsRead = new SqlCommand();
            cmdsRead.Connection = DBConnection;
            cmdsRead.Connection.ConnectionString = DBConnectionString;
            cmdsRead.CommandText = sqlQuery;
            cmdsRead.Connection.Open();
            SqlDataReader sID = cmdsRead.ExecuteReader();

            return sID;

        }
        public static SqlDataReader FacFinder(String HttpContext)
        {
            String sqlQuery = "SELECT FacultyID FROM Faculty WHERE FacultyUsername = '" + HttpContext + "';";

            SqlCommand cmdsRead = new SqlCommand();
            cmdsRead.Connection = DBConnection;
            cmdsRead.Connection.ConnectionString = DBConnectionString;
            cmdsRead.CommandText = sqlQuery;
            cmdsRead.Connection.Open();
            SqlDataReader sID = cmdsRead.ExecuteReader();

            return sID;

        }

        public static SqlDataReader lookStudent(int StudentID)
        {
            String sqlQuery = "select  M.MeetingName, M.MeetingPurpose, M.MeetingDateTime " +
                "from Meeting M, Student S where S.StudentID = M.StudentID AND S.StudentID = '";
            sqlQuery += StudentID + "'";

            SqlCommand cmdmeetRead = new SqlCommand();
            cmdmeetRead.Connection = DBConnection;
            cmdmeetRead.Connection.ConnectionString = DBConnectionString;
            cmdmeetRead.CommandText = sqlQuery;
            cmdmeetRead.Connection.Open();

            SqlDataReader tempReader = cmdmeetRead.ExecuteReader();

            return tempReader;

        }
        public static SqlDataReader FindFaculty(Faculty f)
        {

            
            SqlCommand cmdOfficeHourRead = new SqlCommand();
            cmdOfficeHourRead.Connection = DBConnection;
            cmdOfficeHourRead.Connection.ConnectionString = DBConnectionString;
            cmdOfficeHourRead.CommandText = "SELECT FacultyID FROM Faculty WHERE FacultyName = " + f.FacultyName;
            cmdOfficeHourRead.Connection.Open();

            SqlDataReader tempReader = cmdOfficeHourRead.ExecuteReader();
            return tempReader;

        }


    }

 }
