using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class StudentSummaryPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
