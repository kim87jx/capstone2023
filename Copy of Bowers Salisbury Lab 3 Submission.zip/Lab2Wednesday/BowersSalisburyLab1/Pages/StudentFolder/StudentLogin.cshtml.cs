using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class StudentLoginModel : PageModel
    {
        [BindProperty]
        public Student stu { get; set; }

        public String LoginMessage { get; set; }

        //Logout Message
        public void OnGet(String logout)
        {
            if (logout != null)
            {
                HttpContext.Session.Clear();
                LoginMessage = "Logged out Successfully!";
            }
            
        }

        //Login query to confirm credentials exist and are correct
        public IActionResult OnPost()
        {
            String loginQuery = "SELECT COUNT(*) FROM Student where StudentEmail = '";
            loginQuery += stu.StudentUsername + "' and StudentPW='" + stu.StudentPW + "'";


            if (DBClass.LoginQuery(loginQuery) > 0)
            {
                HttpContext.Session.SetString("stu.StudentEmail", stu.StudentUsername);
                return RedirectToPage("StudentFirstPage");
            }
            else
            {
                LoginMessage = "Email or Password Incorrect";
            }
            DBClass.DBConnection.Close();
            return Page();
        }
    }
}