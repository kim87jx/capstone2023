using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class StudentHashedLoginModel : PageModel
    { 
            [BindProperty]
            public string Username { get; set; }
            [BindProperty]
            public string Password { get; set; }

        
            public void OnGet()
            {
            }

            public IActionResult OnPost()
            {
                if (DBClass.StudentHashedParameterLogin(Username, Password))
                {
                    HttpContext.Session.SetString("username", Username);
                    ViewData["LoginMessage"] = "Login Successful!";

                    DBClass.DBConnection.Close();

                    return RedirectToPage("StudentFirstPage");
            }
                else
                {
                    ViewData["LoginMessage"] = "Username and/or Password Incorrect";
                    DBClass.DBConnection.Close();
                    return Page();
                }

            }
        }
    }



        
    
