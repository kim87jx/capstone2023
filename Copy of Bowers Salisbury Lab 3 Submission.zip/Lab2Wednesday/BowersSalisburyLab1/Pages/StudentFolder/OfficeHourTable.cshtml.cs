using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class OfficeHourTableModel : PageModel
    {
        
        public List<OfficeHours> OfficeHoursList { get; set; }

        public OfficeHourTableModel()
        {
            OfficeHoursList = new List<OfficeHours>();
        }
        public void OnGet()
        {
            SqlDataReader OfficeHourReader = DBClass.OfficeHoursReader();
            while (OfficeHourReader.Read()) {
                OfficeHoursList.Add(new OfficeHours
                {
                    OfficeID = Int32.Parse(OfficeHourReader["OfficeID"].ToString()),
                    FacultyID = Int32.Parse(OfficeHourReader["FacultyID"].ToString()),
                    OHDateTime = DateTime.Parse(OfficeHourReader["OHDateTime"].ToString())
                });
            }

        }

    }
}
