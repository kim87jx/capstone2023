using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class ViewMeetingsModel : PageModel
    {
        public List<Meeting> Meet { get; set; }
        [BindProperty]
        [Required]
        public Student MeetingStudent { get; set; }
        public string StudentName { get; set; }
        [BindProperty, Required]
        public int StudentID { get; set; }
        public void OnGet()
        {
            //        SqlDataReader OhRead = DBClass.SearchForOH(MeetingStudent);
            //        while (OhRead.Read())
            //        {
            //            Meet.Add(new Meeting
            //            {
            //                MeetingID = Int32.Parse(OhRead["MeetingID"].ToString()),
            //                MeetingName = OhRead["FacultyName"].ToString(),
            //                MeetingPurpose = OhRead["FacultyEmail"].ToString(),
            //                MeetingDateTime = DateTime.Parse(OhRead["FacultyMeetingDateTime"].ToString()),
            //                OfficeID = Int32.Parse(OhRead["OfficeID"].ToString()),
            //                StudentID = Int32.Parse(OhRead["OfficeID"].ToString()),
            //                FacultyID = Int32.Parse(OhRead["OfficeID"].ToString())
            //            });
            //        }
            //        DBClass.DBConnection.Close();
        }

    }
}
