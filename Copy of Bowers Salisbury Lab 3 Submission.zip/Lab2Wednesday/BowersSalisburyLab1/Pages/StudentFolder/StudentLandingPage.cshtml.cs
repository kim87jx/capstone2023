using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class StudentLandingPageModel : PageModel
    {
        //If student email does not exist, user is not logged in
        public IActionResult OnGet()
        {
            if (HttpContext.Session.GetString("stu.StudentEmail") == null)
            {
                return RedirectToPage("StudentLogin");
            }
            return Page();
        }
    }
}
