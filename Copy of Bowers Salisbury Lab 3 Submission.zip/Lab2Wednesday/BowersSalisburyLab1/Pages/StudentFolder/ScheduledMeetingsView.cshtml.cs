using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class ScheduledMeetingsViewModel : PageModel
    {
        [BindProperty]
        public String stuID { get; set; }

        public List<Student> StuList;

        public ScheduledMeetingsViewModel()
        {
            StuList = new List<Student>();

        }
        public void OnGet()
        {
            SqlDataReader cmdsreader = DBClass.StudentFinder(HttpContext.Session.GetString("username"));
            while (cmdsreader.Read())
            {
                stuID = cmdsreader["StudentID"].ToString();
            }
            DBClass.DBConnection.Close();

            HttpContext.Session.SetString("StudentID", stuID);


            //}
            //    public IActionResult OnPost()
            //    {
            //        SqlDataReader OHReader = DBClass.SearchFaculty(StuID);
            //        while (OHReader.Read())
            //        {
            //            StuList.Add(new OfficeHours
            //            {
            //                OfficeID = Int32.Parse(OHReader["OfficeID"].ToString()),
            //                OHDateTime = DateTime.Parse(OHReader["OHDateTime"].ToString()),


            //            });
        }
    }
}
