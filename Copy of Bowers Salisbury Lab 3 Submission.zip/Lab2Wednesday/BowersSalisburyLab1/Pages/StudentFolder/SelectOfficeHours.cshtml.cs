using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.SignalR.Protocol;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class SelectOfficeHoursModel : PageModel
    {

        [BindProperty]
        public Meeting NewMeeting { get; set; }

        public SelectOfficeHoursModel()
        {
            NewMeeting = new Meeting();

        }
        public void OnGet()
        {
            //SqlDataReader singleFaculty = DBClass.SearchFaculty(FacultyID);

            //while (singleFaculty.Read())
            //{
            //    FacultyID = Int32.Parse(SearchFaculty["FacultyID"].ToString()),
            //        FacultyName = SearchFaculty["FacultyName"].ToString(),
            //        FacultyEmail = SearchFaculty["FacultyEmail"].ToString(),
            //        FacultyMeetingDateTime = DateTime.Parse(SearchFaculty["FacultyMeetingDateTime"].ToString())
            //}
            //DBClass.DBConnection.Close();
            SqlDataReader cmdsreader = DBClass.StudentFinder(HttpContext.Session.GetString("username"));
            while (cmdsreader.Read())
            {
                NewMeeting.StudentID = Int32.Parse(cmdsreader["StudentID"].ToString());
            }
            DBClass.DBConnection.Close();
        }
        public IActionResult OnPost()
        {
            DBClass.InsertMeeting(NewMeeting);
            DBClass.DBConnection.Close();
            return RedirectToPage("SignUpConfirmation");
        }
    }
}
