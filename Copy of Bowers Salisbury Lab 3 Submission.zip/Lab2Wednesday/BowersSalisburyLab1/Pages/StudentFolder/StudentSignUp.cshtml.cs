using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.VisualBasic;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class StudentSignUpModel : PageModel
    {

        // Properties for Single Select Dropdown
        [BindProperty] public String FacultyN { get; set; }
        [BindProperty] public int SelectOH { get; set; }
        public String SelectNotification { get; set; }

        public List<Faculty> FacultyList;

        public List<OfficeHours> OHList; 

      

        public StudentSignUpModel()
        {
            FacultyList = new List<Faculty>();
            OHList = new List<OfficeHours>();
        }

        //Adds faculty member to list
        public void OnGet()
        {
            SqlDataReader FacultyReader = DBClass.FacultyReader();
            while (FacultyReader.Read())
            {
                FacultyList.Add(new Faculty
                {
                    FacultyID = Int32.Parse(FacultyReader["FacultyID"].ToString()),
                    FacultyName = FacultyReader["FacultyName"].ToString(),
                    FacultyEmail = FacultyReader["FacultyEmail"].ToString(),
                    FacultyMeetingDateTime = DateTime.Parse(FacultyReader["FacultyMeetingDateTime"].ToString())

                });
            }
            DBClass.DBConnection.Close();
        }
        //adds  office hours to office hour list
        public IActionResult OnPost()
        {
            SqlDataReader OHReader = DBClass.SearchFaculty(FacultyN);
            while (OHReader.Read())
            {
                OHList.Add(new OfficeHours
                {
                    OfficeID = Int32.Parse(OHReader["OfficeID"].ToString()),
                    OHDateTime = DateTime.Parse(OHReader["OHDateTime"].ToString()),
                   

                });
            }

            DBClass.DBConnection.Close();

            SqlDataReader FacultyReader = DBClass.FacultyReader();
            while (FacultyReader.Read())
            {
                FacultyList.Add(new Faculty
                {
                    FacultyID = Int32.Parse(FacultyReader["FacultyID"].ToString()),
                    FacultyName = FacultyReader["FacultyName"].ToString(),
                    FacultyEmail = FacultyReader["FacultyEmail"].ToString(),
                    FacultyMeetingDateTime = DateTime.Parse(FacultyReader["FacultyMeetingDateTime"].ToString())

                });
            }
            
            DBClass.DBConnection.Close();

            return Page();
    }
}
}
