using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class SignUpConfirmationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
