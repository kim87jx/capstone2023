using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class FacultyOfficeHoursModel : PageModel
    {
       
      

 
    }
}
