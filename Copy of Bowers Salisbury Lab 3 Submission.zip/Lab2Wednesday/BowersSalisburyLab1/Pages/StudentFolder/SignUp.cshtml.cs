using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class SignUpModel : PageModel
    {
        public List<Faculty> FacultyList { get; set; }

        public SignUpModel()
        {
            FacultyList = new List<Faculty>();
        }

        [BindProperty]
        public int FacultyName { get; set; }
        public void OnGet()
        {
            SqlDataReader FacultyReader = DBClass.FacultyReader();
            while (FacultyReader.Read())
            {
                FacultyList.Add(new Faculty
                {
                    FacultyID = Int32.Parse(FacultyReader["FacultyID"].ToString()),
                    FacultyName = FacultyReader["FacultyName"].ToString(),
                    FacultyEmail = FacultyReader["FacultyEmail"].ToString(),
                    FacultyMeetingDateTime = DateTime.Parse(FacultyReader["FacultyMeetingDateTime"].ToString()),
                    OfficeID = Int32.Parse(FacultyReader["OfficeID"].ToString())
                }) ;
            }
            DBClass.DBConnection.Close();
        }

        public IActionResult OnPost()
        {
            return Page();
        }
    }
}
