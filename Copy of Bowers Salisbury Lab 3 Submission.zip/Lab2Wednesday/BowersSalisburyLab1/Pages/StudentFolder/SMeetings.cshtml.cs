using BowersSalisburyLab1.Pages.DataClasses;
using BowersSalisburyLab1.Pages.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace BowersSalisburyLab1.Pages.StudentFolder
{
    public class SMeetingsModel : PageModel
    {


        // Properties for Single Select Dropdown
        [BindProperty] public int SelectStudent { get; set; }
        [BindProperty] public int SelectMeeting { get; set; }
        public String SelectNotification { get; set; }

        public List<Student> StudentList;

        public List<Meeting> MeetingsList;



        public SMeetingsModel()
        {
            StudentList = new List<Student>();
            MeetingsList = new List<Meeting>();
        }

        //Add student to studentlist
        public void OnGet()
        {
            SqlDataReader StudentReader = DBClass.StudentReader();
            while (StudentReader.Read())
            {
                StudentList.Add(new Student
                {
                    StudentID = Int32.Parse(StudentReader["StudentID"].ToString()),
                    StudentName = StudentReader["StudentName"].ToString(),
                    StudentPW = StudentReader["StudentPW"].ToString(),
                    StudentUsername = StudentReader["StudentUsername"].ToString()
                });
            }
            DBClass.DBConnection.Close();
        }

        //Adds meetings to meetinglist
        public IActionResult OnPost()
        {
            SqlDataReader MeetingReader = DBClass.SearchStudent((HttpContext.Session.GetString("username")));
            while (MeetingReader.Read())
            {
                MeetingsList.Add(new Meeting
                {
                    MeetingName = MeetingReader["MeetingName"].ToString(),
                    MeetingPurpose = MeetingReader["MeetingPurpose"].ToString(),
                    MeetingDateTime = DateTime.Parse(MeetingReader["MeetingDateTime"].ToString())

                });
            }
            DBClass.DBConnection.Close();

            SqlDataReader StudentReader = DBClass.StudentReader();
            while (StudentReader.Read())
            {
                StudentList.Add(new Student
                {
                    StudentID = Int32.Parse(StudentReader["StudentID"].ToString()),
                    StudentName = StudentReader["StudentName"].ToString(),
                    StudentPW = StudentReader["StudentPW"].ToString(),
                    StudentUsername = StudentReader["StudentUsername"].ToString()
                });
            }
            DBClass.DBConnection.Close();

            return Page();

        }
    }
}

    






