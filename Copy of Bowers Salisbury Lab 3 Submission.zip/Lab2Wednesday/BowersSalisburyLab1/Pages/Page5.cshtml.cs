using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BowersSalisburyLab1.Pages
{
    public class Page5Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
