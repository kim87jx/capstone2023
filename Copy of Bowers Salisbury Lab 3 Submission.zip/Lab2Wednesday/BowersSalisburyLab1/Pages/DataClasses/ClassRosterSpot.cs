﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class ClassRosterSpot
    {
        public int StudentID { get; set; }
        public int ClassID { get; set; }

    }
}
