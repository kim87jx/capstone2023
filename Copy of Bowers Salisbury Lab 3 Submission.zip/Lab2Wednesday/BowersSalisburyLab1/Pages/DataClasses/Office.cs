﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class Office
    {
        public int OfficeID { get; set; }
        public String OfficeLocation { get; set; }
        public String WaitingRoom { get; set; }

    }
}
