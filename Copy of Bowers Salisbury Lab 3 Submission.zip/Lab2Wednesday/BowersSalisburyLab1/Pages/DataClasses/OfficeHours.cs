﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class OfficeHours
    {
        public int OfficeID { get; set; }
        public int FacultyID { get; set; }
        public DateTime OHDateTime { get; set; }

    }
}
