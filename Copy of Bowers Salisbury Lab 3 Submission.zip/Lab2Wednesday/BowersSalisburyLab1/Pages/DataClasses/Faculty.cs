﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class Faculty
    {
        public int FacultyID { get; set; }
        public String FacultyName { get; set; }
        public String FacultyEmail { get; set; }
        public DateTime? FacultyMeetingDateTime { get; set; }
        public int OfficeID { get; set; }

        public String FacultyPW { get; set; }
    }
}
