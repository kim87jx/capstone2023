﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class Meeting
    {
        public int MeetingID { get; set; }
        public String? MeetingName { get; set; }
        public String? MeetingPurpose { get; set; }
        public DateTime? MeetingDateTime { get; set; }
        public int OfficeID { get; set; }
        public int FacultyID { get; set; }
        public int StudentID { get; set; }
        public int NumOfStudents { get; set; }
    }
}
