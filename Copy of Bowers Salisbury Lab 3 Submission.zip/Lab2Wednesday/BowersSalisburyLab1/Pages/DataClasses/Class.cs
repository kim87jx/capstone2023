﻿namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class Class
    {
        public int ClassID { get; set; }   
        public int ClassSection { get; set; }
        public int FacultyID { get; set; }

    }
}
