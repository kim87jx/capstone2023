﻿using Microsoft.AspNetCore.Mvc;

namespace BowersSalisburyLab1.Pages.DataClasses
{
    public class Student
    {
        public int StudentID { get; set; }

        public String StudentName { get; set; }

        public String StudentPW { get; set; }

        public String StudentUsername { get; set; }

    }
}
